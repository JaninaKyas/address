<?php
session_start();
error_reporting(-1);
require __DIR__ . '/composer_vendor/autoload.php';
return require __DIR__ . '/includes/config.php';