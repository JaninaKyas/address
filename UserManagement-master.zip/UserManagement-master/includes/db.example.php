<?php
// DB credentials.
define('DB_HOST','locahost');
define('DB_USER','username');
define('DB_PASS','password');
define('DB_NAME','databasename');