﻿<?php

require __DIR__ . '/../../includes/config.php';
