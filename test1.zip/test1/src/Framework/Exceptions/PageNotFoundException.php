<?php

namespace Framework\Exceptions;

use DomainException;

class PageNotFoundException extends DomainException
{
}