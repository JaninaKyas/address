<!DOCTYPE html>
<html>
<head>
    <title>{% yield title %}</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/water.css">
</head>
<body>

{% yield body %}

</body>
</html>
