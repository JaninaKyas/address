<?php

return [
    "example" => \App\Middleware\MiddlewareExample::class
];