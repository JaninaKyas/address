<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

class Users
{
    public function index()
    {
        echo "Hello from a namespaced controller";
    }
}