{% extends "base.mvc.php" %}

{% block title %}Home{% endblock %}

{% block body %}

<h1>Home</h1>

{% endblock %}