<form method="post" action="/welcome">
  <input type="hidden" name="_method" value="put" />
  
  <button>Save changes</button>
</form>