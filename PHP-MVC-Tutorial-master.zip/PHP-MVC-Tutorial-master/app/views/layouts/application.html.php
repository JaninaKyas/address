<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $site_title ?></title>
<meta charset="utf-8" />

</head>
<body>
  
  {PAGE_CONTENT}
  
  <p><a style="color: blue" href="https://github.com/BaylorRae/PHP-MVC-Tutorial">https://github.com/BaylorRae/PHP-MVC-Tutorial</a></p>
</body>
</html>