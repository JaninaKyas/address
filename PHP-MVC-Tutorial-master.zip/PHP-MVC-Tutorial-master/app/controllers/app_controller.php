<?php

class AppController extends Controller {
  public $site_title = 'PHP MVC Framework';
  
}