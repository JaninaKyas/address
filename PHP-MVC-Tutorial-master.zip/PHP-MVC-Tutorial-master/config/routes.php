<?php
// Runs top to bottom (most important should be at the top)

Map::get('/', 'welcome#index');

Map::resource('welcome');