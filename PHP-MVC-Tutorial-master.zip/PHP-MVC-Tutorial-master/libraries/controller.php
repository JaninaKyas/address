<?php

// contain's methods for all the user defined controllers
class Controller extends Object {
  

  
}