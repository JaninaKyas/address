<form method="post" action="/welcome">
  <button>Save changes</button>
</form>