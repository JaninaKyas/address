<?php

/**
 * Handle the errors of the application
 */
class Error extends Controller
{

  function __construct()
  {
    parent::__construct();
    echo "error";
  }
}
