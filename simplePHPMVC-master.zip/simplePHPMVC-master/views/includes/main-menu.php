<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">System Name</a>
    </div>

    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="fa fa-user"></span> Profile</a></li>
      <li><a href="<?php echo base_url . "logout/action" ?>"><span class="fa fa-sign-out"></span> Logout</a></li>
    </ul>
  </div>
</nav>
