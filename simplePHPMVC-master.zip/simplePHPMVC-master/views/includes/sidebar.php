<div class="panel panel-default panel-flush">
  <div class="panel-body">
      <ul class="nav" role="tablist">
          <li role="presentation">
              <a href="<?php echo base_url.'dashboard' ?>">
                  Dashboard
              </a>
          </li>
          <li role="presentation">
              <a href="<?php echo base_url.'users' ?>">
                  Users
              </a>
          </li>
      </ul>
  </div>
</div>
