<h1>Sample Page 1</h1>
<hr>
<h3>Sample queried data in model</h3>
<pre>
<?php 
    print_r($data->query_data);
?>
</pre>
<a href="/php_mvc">Back to Default Page</a>
